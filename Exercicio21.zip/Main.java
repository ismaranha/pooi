
public class Main {

	public static void main(String[] args) {

		Mamifero camelo = new Mamifero("Camelo", 1.8, 4, "Marrom", "Terra", 18.0556);
		Peixe tubarao = new Peixe("Tubar�o", 7.51, 0, "Cinza", "Mar", 13.88);
		Mamifero urso = new Mamifero("Urso-Canadense", 2.8, 4, "Marrom", "Terra", 16.66);
		
		System.out.println("--------------------------------------------------------------------");
		camelo.listaDados();
		System.out.println("--------------------------------------------------------------------");
		tubarao.listaDados();
		System.out.println("--------------------------------------------------------------------");
		urso.listaDados();
	}

}
