import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		char tipoLampada;
		byte ligar;
		
		Scanner tec = new Scanner(System.in);
		Lampada l = new Lampada();
		
		System.out.println("Qual tipo de lampada voce quer criar ?");
		System.out.println("F - Flourescente\nL - Led");
		
		do
		{
			tipoLampada = tec.next().toUpperCase().charAt(0); //coloca tudo em maiusculo para compara��o
			
			if(tipoLampada != 'F' && tipoLampada != 'L')
			{
				System.out.println("Digite F ou L");
			}
		}while(tipoLampada != 'F' && tipoLampada != 'L'); 
		
		do
		{
			System.out.println("Voce quer ligar ou desligar a lampada ?");
			System.out.println("1 - Ligar\n2 - Desligar");
			ligar = tec.nextByte();
			
			if (ligar == 1)
			{
				l.ligar();
			}
			else if (ligar == 2)
			{
				l.desligar();
			}
			else
			{
				System.out.println("Digite 1 ou 2\n");	
			}
		}while (ligar != 1 && ligar != 2);
		
		if(tipoLampada == 'F')
			System.out.println("O tipo da lampada � Flourescente" + " e esta " + l.mostraEstado());
		else
			System.out.println("O tipo da lampada � Led e esta" + " e esta "+ l.mostraEstado());
		
	}	
}
