
public class Led extends Lampada{
	
	@Override
	public String mostraEstado() {
		
		return super.mostraEstado();
	}
}
