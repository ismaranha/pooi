
public class Fluorescente extends Lampada{

	@Override
	public String mostraEstado() {

		return super.mostraEstado();
	}
	
}
