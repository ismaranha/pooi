
public class FabricaLampadas {
	
	public Lampada criaLampada(char tipo){
		if(tipo == 'L'){
			Led l = new Led();
			return l;
		}
		if(tipo == 'F'){
			Fluorescente f = new Fluorescente();
			return f;
		}
		return null;
	}

}
