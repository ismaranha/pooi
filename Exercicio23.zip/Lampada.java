
public class Lampada {
	private boolean estado;
	
	public void ligar(){
		this.estado = true;
	}
	
	public void desligar(){
		this.estado = false;
	}
	
	public String mostraEstado() {
		if (this.estado == true){
			return "Ligada";
		}else if(this.estado == false){
			return "Desligada";
		}
		return null;
	}
	
}
