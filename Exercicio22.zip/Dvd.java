
public class Dvd extends Loja{
	private String duracao;
	
	public Dvd(String nome, double preco,String duracao){
		super(nome, preco);
		this.duracao = duracao;
	}

	public String getDuracao() {
		return this.duracao;
	}

	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}
	
	@Override
	public void listaDados() {
		super.listaDados();
		System.out.println("Duracao: " + this.duracao);
	}
}
