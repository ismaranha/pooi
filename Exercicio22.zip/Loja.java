
public class Loja {
	
	private String nome;
	private double preco;
	
	public Loja(String nome, double preco){
		this.nome = nome;
		this.preco = preco;
	}
	
	public void listaDados(){
		System.out.println("Nome: " + this.nome + "\nPreco: " + this.preco);
	}
}
