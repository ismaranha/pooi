
public class Main {

	public static void main(String[] args) {
		
		Cd cd = new Cd("The Dark Side of the moon", 40, 10);
		Cd cd2 = new Cd("Let It Bleed", 49, 9);
		Dvd dvd = new Dvd("Senhor dos Aneis", 149, "3h 55m");
		Livro livro = new Livro("O m�nimo que voc� precisa saber para nao ser um idiota", 54.90, "Olavo de Carvalho");
		Livro livro2 = new Livro("Desinforma��o", 54.90, "Ion Mihai Pacepa");
		
		System.out.println("_____________________CD 1_____________________\n");
		cd.listaDados();
		
		System.out.println("_____________________CD 2_____________________\n");
		cd2.listaDados();
		
		System.out.println("_____________________DVD______________________\n");
		dvd.listaDados();
		
		System.out.println("_____________________LIVRO 1__________________\n");
		livro.listaDados();
		
		System.out.println("_____________________LIVRO 2__________________\n");
		livro2.listaDados();
		
	}

}
