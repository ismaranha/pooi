
public class Cd extends Loja {
	private int numFaixas;
	
	public Cd(String nome, double preco,int nFaixas){
		super(nome, preco);
		this.numFaixas = nFaixas;
	}

	public int getNumFaixas() {
		return numFaixas;
	}

	public void setNumFaixas(int nFaixas) {
		this.numFaixas = nFaixas;
	}
	
	@Override
	public void listaDados() {
		super.listaDados();
		System.out.println("Numero de Faixas: " + this.numFaixas);
	}
}
